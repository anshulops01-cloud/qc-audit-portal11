// Google Sheet sync. Sheet > Extensions > Apps Script > paste > Deploy > Web app (Execute as: Me, Access: Anyone).
// Put the web app URL in SHEET_WEBHOOK_URL and the same TOKEN in SHEET_TOKEN on Netlify.
const TOKEN = 'CHANGE_ME';
function doPost(e) {
  const d = JSON.parse(e.postData.contents);
  if (d.token !== TOKEN) return ContentService.createTextOutput('denied');
  const ss = SpreadsheetApp.getActive();
  const sh = ss.getSheetByName('QC_Records') || ss.insertSheet('QC_Records');
  if (sh.getLastRow() === 0) sh.appendRow(['ID','Date Time (IST)','QC User','Labeler ID','Agent','Dataset','Task/Clip','Error Tags','Errors','Polygons','Polygon Accuracy %','Image Score']);
  sh.appendRow(d.row);
  return ContentService.createTextOutput('ok');
}
