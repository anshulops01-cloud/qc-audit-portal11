# QC Audit Portal

React + Netlify Functions + Postgres (Netlify DB / Neon). Super-admin, supervisors and up to 50 QC users.

## Features
- **QC entry form** (only screen for QC users): labeler-ID search (from uploaded Excel), auto IST timestamp, dataset dropdown, multi-select error tags (CSV), task/clip name (100 chars), **total polygons**.
- **Scoring**: *Image score* = 0 if the image has any error, else 100. *Polygon accuracy* = (polygons − errors) / polygons. Both are stored per record and rolled up in reports.
- **Dataset authorization**: QC users only see/submit labelers from datasets assigned to them by the admin or a supervisor (enforced on the server).
- **Roles**: `admin` (everything, active/inactive, report rights, uploads, edit/delete), `supervisor` (assign datasets, reports), `qc` (entry; optional reports).
- **36-hour rule**: if the Excel was not uploaded within the expiry window, QC users get a blocking pop-up and cannot submit.
- **Dashboard & reports**: daily/weekly/monthly, per labeler/agent/QC/dataset, search, date filters, charts, Excel export.
- **Time tracking**: counts active seconds only while the tab is visible/focused and there was mouse/keyboard activity in the last 5 s (`IDLE_MS` in `src/App.jsx`). Flushed every 15 s.
- **Google Sheet sync**: every submitted record is POSTed to an Apps Script web app (`apps-script/Code.gs`).

## Deploy
1. Push this repo to GitHub, then *Netlify → Add new site → Import from Git*.
2. Add a database (Netlify DB, or any Postgres via `DATABASE_URL`). Tables are created automatically on first request.
3. Set env vars from `.env.example` (`JWT_SECRET`, `ADMIN_USER`, `ADMIN_PASSWORD`, optional sheet vars).
4. Open the site and log in with `ADMIN_USER` / `ADMIN_PASSWORD` (creates the super admin when no users exist).
5. Uploads tab → upload the assignment Excel and the error CSV. Users tab → add QCs, tick their datasets.

Local: `npm i -g netlify-cli && npm i && netlify dev`.

## Excel columns used
`Project Name` (dataset), `Date`, `Employee Name`, `Login Id` (labeler ID), `No. of Assets`, `No. of Annotation`. Rows with "No record found" are skipped.
