import { useEffect, useMemo, useState } from 'react';
import * as XLSX from 'xlsx';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { api, fmt } from './api.js';

const ist = (d = 0) => new Date(Date.now() + 5.5 * 36e5 - d * 864e5).toISOString().slice(0, 10);
const wk = d => { const x = new Date(d + 'T00:00:00Z'); x.setUTCDate(x.getUTCDate() - ((x.getUTCDay() + 6) % 7)); return x.toISOString().slice(0, 10); };
const per = { day: r => r.ts.slice(0, 10), week: r => wk(r.ts.slice(0, 10)), month: r => r.ts.slice(0, 7) };
const agg = (rows, key, label) => {
  const m = {};
  rows.forEach(r => { const k = key(r), x = (m[k] ||= { a: 0, p: 0, e: 0, i: 0 }); x.a++; x.p += r.total_polygons; x.e += r.error_count; x.i += r.image_score; });
  return Object.entries(m).sort().map(([k, x]) => ({ [label]: k, Audits: x.a, Polygons: x.p, Errors: x.e, 'Image Score %': +(x.i / x.a).toFixed(1), 'Polygon Accuracy %': +Math.max(0, ((x.p - x.e) / x.p) * 100).toFixed(1) }));
};
const Tbl = ({ rows }) => !rows.length ? <p>No data.</p> : <div className="scroll"><table><thead><tr>{Object.keys(rows[0]).map(k => <th key={k}>{k}</th>)}</tr></thead><tbody>{rows.map((r, i) => <tr key={i}>{Object.values(r).map((v, j) => <td key={j}>{v}</td>)}</tr>)}</tbody></table></div>;
const Chart = ({ title, data, x, y, line }) => (
  <div className="card"><b>{title}</b><ResponsiveContainer width="100%" height={240}>
    {line ? <LineChart data={data}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey={x} /><YAxis /><Tooltip /><Line dataKey={y} stroke="#2f6fd6" /></LineChart>
      : <BarChart data={data}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey={x} /><YAxis /><Tooltip /><Bar dataKey={y} fill="#2f6fd6" /></BarChart>}
  </ResponsiveContainer></div>
);

export default function Reports({ me }) {
  const [from, setFrom] = useState(ist(7)), [to, setTo] = useState(ist()), [s, setS] = useState(''), [p, setP] = useState('day'), [tab, setTab] = useState('dash'), [by, setBy] = useState('labeler');
  const [rows, setRows] = useState([]), [time, setTime] = useState([]), [cat, setCat] = useState({});
  const load = () => {
    api(`/records?from=${from}&to=${to}&q=${encodeURIComponent(s)}`).then(setRows);
    api(`/time-report?from=${from}&to=${to}`).then(setTime);
    api('/options').then(o => setCat(Object.fromEntries(o.errors.map(e => [e.tag, e.category]))));
  };
  useEffect(load, [from, to]);
  const keys = { labeler: [r => `${r.labeler_id} — ${r.agent}`, 'Labeler'], qc: [r => r.qc_user, 'QC User'], dataset: [r => r.dataset, 'Dataset'], combo: [r => `${r.dataset} | ${r.labeler_id} — ${r.agent}`, 'Dataset | Labeler'], period: [per[p], p[0].toUpperCase() + p.slice(1)] };
  const summ = useMemo(() => agg(rows, ...keys[by]), [rows, by, p]);
  const k = useMemo(() => { const t = agg(rows, () => 'all', 'x')[0]; return t; }, [rows]);
  const over = useMemo(() => agg(rows, per[p], 'Period'), [rows, p]);
  const topTags = useMemo(() => { const c = {}; rows.forEach(r => r.error_tags.forEach(t => t !== 'NO_ERROR' && (c[t] = (c[t] || 0) + 1))); return Object.entries(c).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([Tag, Count]) => ({ Tag, Count })); }, [rows]);
  const byCat = useMemo(() => { const c = {}; rows.forEach(r => r.error_tags.forEach(t => t !== 'NO_ERROR' && (c[cat[t] || 'Other'] = (c[cat[t] || 'Other'] || 0) + 1))); return Object.entries(c).map(([Category, Count]) => ({ Category, Count })); }, [rows, cat]);
  const perUserTime = useMemo(() => { const c = {}; time.forEach(t => (c[t.username] = (c[t.username] || 0) + t.seconds)); return Object.entries(c).map(([User, s]) => ({ User, Hours: +(s / 3600).toFixed(2) })); }, [time]);
  const del = async id => { if (confirm('Delete this record?')) { await api('/records/' + id, { method: 'DELETE' }); load(); } };
  const exp = () => {
    const wb = XLSX.utils.book_new(), add = (n, d) => XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(d), n.slice(0, 31));
    add('Records', rows.map(r => ({ ID: r.id, 'Date Time (IST)': r.ts, 'QC User': r.qc_user, 'Labeler ID': r.labeler_id, Agent: r.agent, Dataset: r.dataset, 'Task/Clip': r.task_name, 'Error Tags': r.error_tags.join(', '), Errors: r.error_count, Polygons: r.total_polygons, 'Polygon Accuracy %': r.polygon_accuracy, 'Image Score': r.image_score })));
    ['labeler', 'qc', 'dataset', 'combo'].forEach(b => add('By ' + keys[b][1], agg(rows, ...keys[b])));
    ['day', 'week', 'month'].forEach(x => add('By ' + x, agg(rows, per[x], x)));
    add('Time Spent', time.map(t => ({ Date: t.day, User: t.username, Name: t.name, Seconds: t.seconds, Time: fmt(t.seconds) })));
    XLSX.writeFile(wb, `qc_report_${from}_to_${to}.xlsx`);
  };
  return (<>
    <div className="card row">
      <input type="date" style={{ width: 150 }} value={from} onChange={e => setFrom(e.target.value)} /><input type="date" style={{ width: 150 }} value={to} onChange={e => setTo(e.target.value)} />
      {[['Today', 0, 0], ['7 days', 7, 0], ['30 days', 30, 0]].map(([l, a]) => <button key={l} onClick={() => { setFrom(ist(a)); setTo(ist()); }}>{l}</button>)}
      <input style={{ flex: 1, minWidth: 200 }} placeholder="Search labeler, agent, QC, dataset, task, error…" value={s} onChange={e => setS(e.target.value)} onKeyDown={e => e.key === 'Enter' && load()} />
      <button className="pri" style={{ width: 90 }} onClick={load}>Search</button>
      <select style={{ width: 120 }} value={p} onChange={e => setP(e.target.value)}><option value="day">Daily</option><option value="week">Weekly</option><option value="month">Monthly</option></select>
      <button className="pri" style={{ width: 150 }} onClick={exp}>Export to Excel</button>
    </div>
    <nav className="row" style={{ marginBottom: 10 }}>{[['dash', 'Dashboard'], ['sum', 'Summary'], ['rec', 'Records'], ['time', 'Time spent']].map(([t, l]) => <button key={t} className={tab === t ? 'on' : ''} style={{ color: '#1f3a5f' }} onClick={() => setTab(t)}>{l}</button>)}</nav>
    {tab === 'dash' && <>
      {k && <div className="kpis">{[['Audits', k.Audits], ['Polygons', k.Polygons], ['Errors', k.Errors], ['Image score', k['Image Score %'] + '%'], ['Polygon accuracy', k['Polygon Accuracy %'] + '%']].map(([l, v]) => <div className="kpi" key={l}>{l}<b>{v}</b></div>)}</div>}
      <br /><div className="charts">
        <Chart title="Audits over time" data={over} x="Period" y="Audits" line />
        <Chart title="Image score % over time" data={over} x="Period" y="Image Score %" line />
        <Chart title="Top 10 error tags" data={topTags} x="Tag" y="Count" />
        <Chart title="Errors by category" data={byCat} x="Category" y="Count" />
        <Chart title="Audits per QC" data={agg(rows, r => r.qc_user, 'QC')} x="QC" y="Audits" />
        <Chart title="Image score % per dataset" data={agg(rows, r => r.dataset, 'Dataset')} x="Dataset" y="Image Score %" />
      </div></>}
    {tab === 'sum' && <div className="card"><select style={{ width: 260 }} value={by} onChange={e => setBy(e.target.value)}><option value="labeler">Per labeler / agent</option><option value="qc">Per QC user</option><option value="dataset">Per dataset</option><option value="combo">Dataset × labeler</option><option value="period">Per {p}</option></select><br /><br /><Tbl rows={summ} /></div>}
    {tab === 'rec' && <div className="card scroll"><table><thead><tr>{['Date time', 'QC', 'Labeler', 'Agent', 'Dataset', 'Task/clip', 'Errors', 'Polys', 'Acc %', 'Img', ''].map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>
      {rows.map(r => <tr key={r.id}><td>{r.ts}</td><td>{r.qc_user}</td><td>{r.labeler_id}</td><td>{r.agent}</td><td>{r.dataset}</td><td>{r.task_name}</td><td>{r.error_tags.join(', ')}</td><td>{r.total_polygons}</td><td>{r.polygon_accuracy}</td><td>{r.image_score}</td><td>{me.role === 'admin' && <button onClick={() => del(r.id)}>🗑</button>}</td></tr>)}</tbody></table></div>}
    {tab === 'time' && <><Chart title="Active hours per user" data={perUserTime} x="User" y="Hours" /><div className="card"><Tbl rows={time.map(t => ({ Date: t.day, User: t.username, Name: t.name, 'Active time': fmt(t.seconds) }))} /></div></>}
  </>);
}
