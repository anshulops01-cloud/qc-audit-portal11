import { useEffect, useRef, useState } from 'react';
import { api, fmt } from './api.js';
import QCForm from './QCForm.jsx';
import Reports from './Reports.jsx';
import { Users, Uploads } from './Admin.jsx';

const IDLE_MS = 5000; // time counts only if mouse/keyboard activity happened in the last 5 seconds
const logout = () => { localStorage.removeItem('t'); location.reload(); };

// Active-time tracker: counts a second only when the tab is visible+focused and the user was active <5s ago.
function useActiveTimer(idleLogoutMin) {
  const [sec, setSec] = useState(0), last = useRef(Date.now()), pend = useRef(0);
  useEffect(() => {
    const bump = () => (last.current = Date.now());
    const ev = ['mousemove', 'mousedown', 'keydown', 'wheel', 'touchstart', 'scroll'];
    ev.forEach(e => addEventListener(e, bump, { passive: true }));
    const tick = setInterval(() => {
      if (Date.now() - last.current > idleLogoutMin * 60000) return logout();
      if (!document.hidden && document.hasFocus() && Date.now() - last.current <= IDLE_MS) { setSec(s => s + 1); pend.current++; }
    }, 1000);
    const flush = setInterval(() => {
      const n = pend.current; if (!n) return; pend.current = 0;
      api('/time', { method: 'POST', body: { seconds: n } }).catch(() => (pend.current += n));
    }, 15000);
    return () => { ev.forEach(e => removeEventListener(e, bump)); clearInterval(tick); clearInterval(flush); };
  }, [idleLogoutMin]);
  return sec;
}

function Login({ onDone }) {
  const [u, setU] = useState(''), [p, setP] = useState(''), [err, setErr] = useState('');
  const go = async () => { try { const d = await api('/login', { method: 'POST', body: { username: u, password: p } }); localStorage.setItem('t', d.token); onDone(); } catch (e) { setErr(e.message); } };
  return (
    <main style={{ maxWidth: 380, marginTop: 80 }}><div className="card">
      <h2>QC Audit Portal</h2>{err && <div className="bad">{err}</div>}
      <label>Username</label><input value={u} onChange={e => setU(e.target.value)} />
      <label>Password</label><input type="password" value={p} onChange={e => setP(e.target.value)} onKeyDown={e => e.key === 'Enter' && go()} />
      <br /><br /><button className="pri" onClick={go}>Login</button>
    </div></main>
  );
}

function Shell({ me }) {
  const { user, settings } = me, sec = useActiveTimer(settings.idle_logout);
  const tabs = [['entry', 'QC Entry']];
  if (user.role !== 'qc' || user.can_report) tabs.push(['reports', 'Reports & Dashboard']);
  if (user.role !== 'qc') tabs.push(['users', 'Users & Datasets']);
  if (user.role === 'admin') tabs.push(['uploads', 'Uploads & Settings']);
  const [tab, setTab] = useState('entry');
  return (<>
    <header><b>QC Audit Portal</b>
      <nav>{tabs.length > 1 && tabs.map(([k, l]) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}</button>)}</nav>
      <span>⏱ Active today: {fmt(me.today_seconds + sec)}</span><span>{user.username} ({user.role})</span><button onClick={logout}>Logout</button>
    </header>
    <main>
      {me.stale && user.role !== 'qc' && <div className="bad">⚠ Labeler list is older than {settings.stale_hours} hours. QC users are blocked until you upload a new list.</div>}
      {tab === 'entry' && <QCForm me={user} />}
      {tab === 'reports' && <Reports me={user} />}
      {tab === 'users' && <Users me={user} />}
      {tab === 'uploads' && <Uploads settings={settings} />}
    </main>
  </>);
}

export default function App() {
  const [me, setMe] = useState(null), [load, setLoad] = useState(!!localStorage.getItem('t'));
  const boot = () => { if (!localStorage.getItem('t')) return setLoad(false); api('/me').then(setMe).catch(() => localStorage.removeItem('t')).finally(() => setLoad(false)); };
  useEffect(boot, []);
  if (load) return <main>Loading…</main>;
  return me ? <Shell me={me} /> : <Login onDone={() => { setLoad(true); boot(); }} />;
}
