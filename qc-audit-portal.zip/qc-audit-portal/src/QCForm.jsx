import { useEffect, useState } from 'react';
import { api } from './api.js';

export default function QCForm({ me }) {
  const [o, setO] = useState(null), [q, setQ] = useState(''), [lab, setLab] = useState(null), [ds, setDs] = useState('');
  const [tags, setTags] = useState([]), [eq, setEq] = useState(''), [task, setTask] = useState(''), [poly, setPoly] = useState('');
  const [msg, setMsg] = useState(''), [busy, setBusy] = useState(false);
  const load = () => api('/options').then(setO); useEffect(() => { load(); }, []);
  if (!o) return <p>Loading…</p>;
  const labs = [...new Map(o.rows.map(r => [r.labeler_id, r])).values()];
  const hits = q && !lab ? labs.filter(r => r.labeler_id.toLowerCase().includes(q.toLowerCase())).slice(0, 8) : [];
  const mine = lab ? o.rows.filter(r => r.labeler_id === lab.labeler_id) : [];
  const row = mine.find(r => r.dataset === ds), S = o.settings;
  const warn = row && (row.age_h < S.audit_min || row.age_h > S.audit_max);
  const P = +poly, E = tags.includes('NO_ERROR') ? 0 : tags.length;
  const acc = P > 0 ? (E ? Math.max(0, ((P - E) / P) * 100) : 100) : null;
  const pick = r => { setLab(r); setQ(r.labeler_id); const d = o.rows.filter(x => x.labeler_id === r.labeler_id); setDs(d.length === 1 ? d[0].dataset : ''); };
  const tog = t => setTags(s => t === 'NO_ERROR' ? (s.includes(t) ? [] : [t]) : s.includes(t) ? s.filter(x => x !== t) : [...s.filter(x => x !== 'NO_ERROR'), t]);
  const act = o.errors.filter(e => e.active && (!eq || (e.tag + e.category + e.definition).toLowerCase().includes(eq.toLowerCase())));
  const cats = [...new Set(act.map(e => e.category))];
  const ok = lab && ds && tags.length && task.trim() && Number.isInteger(P) && P > 0;
  const save = async force => {
    setBusy(true); setMsg('');
    try {
      await api('/records', { method: 'POST', body: { labeler_id: lab.labeler_id, dataset: ds, task_name: task, tags, polygons: P, force } });
      setLab(null); setQ(''); setDs(''); setTags([]); setTask(''); setPoly(''); setMsg('✔ Saved'); load();
    } catch (e) { if (e.status === 409 && confirm('A record with this labeler, dataset and task name already exists. Save anyway?')) return save(true); setMsg('✖ ' + e.message); }
    finally { setBusy(false); }
  };
  return (<>
    {o.stale && me.role !== 'admin' && <div className="modal"><div><h3>Labeler list outdated</h3><p>The list has not been updated in {S.stale_hours} hours. Please contact the Administration.</p></div></div>}
    {!o.rows.length && <div className="warn">No datasets are assigned to you yet. Contact your supervisor/administrator.</div>}
    <div className="grid">
      <div className="card">
        <div className="row"><b>QC Entry</b><span style={{ marginLeft: 'auto' }}>Today's entries: {o.today_count}</span></div>
        <label>Labeler ID (type any part)</label>
        <input value={q} placeholder="e.g. 818" onChange={e => { setQ(e.target.value); setLab(null); setDs(''); }} />
        {!!hits.length && <div className="sug">{hits.map(r => <button key={r.labeler_id} onClick={() => pick(r)}>{r.labeler_id} — {r.agent}</button>)}</div>}
        {lab && <p>Agent: <b>{lab.agent}</b></p>}
        <label>Dataset name</label>
        <select value={ds} onChange={e => setDs(e.target.value)} disabled={!lab}>
          <option value="">Select dataset…</option>{[...new Set(mine.map(r => r.dataset))].map(d => <option key={d}>{d}</option>)}
        </select>
        {row && <p>Work date {row.wd} ({row.age_h}h ago) {warn && <span className="warn">outside {S.audit_min}–{S.audit_max}h audit window</span>}</p>}
        <label>Task / clip name ({task.length}/100)</label>
        <input maxLength={100} value={task} onChange={e => setTask(e.target.value)} />
        <label>Total polygons in this task</label>
        <input type="number" min="1" value={poly} onChange={e => setPoly(e.target.value)} />
        {acc !== null && <p>Image score: <b>{E ? 0 : 100}</b> · Polygon accuracy: <b>{acc.toFixed(1)}%</b> ({E} error{E === 1 ? '' : 's'})</p>}
        <label>Date & time</label><input disabled value="Auto-stamped on submit (IST)" />
        <br /><br /><button className="pri" disabled={!ok || busy} onClick={() => save(false)}>Submit</button>
        <p>{msg}</p>
      </div>
      <div className="card">
        <b>Error tags ({E} selected)</b>
        <div className="row" style={{ margin: '8px 0' }}>{tags.map(t => <span key={t} className="chip" onClick={() => tog(t)}>{t} ✕</span>)}{!!tags.length && <button onClick={() => setTags([])}>Clear</button>}</div>
        <input placeholder="Search tag, category or definition…" value={eq} onChange={e => setEq(e.target.value)} />
        <div className="errbox">{cats.map(c => <div key={c}><h4>{c}</h4>{act.filter(e => e.category === c).map(e =>
          <label key={e.tag} title={e.definition}><input type="checkbox" checked={tags.includes(e.tag)} onChange={() => tog(e.tag)} />{e.tag}</label>)}</div>)}</div>
      </div>
    </div>
  </>);
}
