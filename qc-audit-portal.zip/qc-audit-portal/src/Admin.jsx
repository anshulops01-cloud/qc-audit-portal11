import { useEffect, useState } from 'react';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';
import { api } from './api.js';

export function Users({ me }) {
  const [us, setUs] = useState([]), [ds, setDs] = useState([]), [f, setF] = useState({ username: '', name: '', password: '', role: 'qc' });
  const load = () => { api('/users').then(setUs); api('/datasets').then(setDs); }; useEffect(load, []);
  const adm = me.role === 'admin', err = e => alert(e.message);
  const upd = (id, b) => api('/users/' + id, { method: 'PUT', body: b }).then(load).catch(err);
  const add = () => api('/users', { method: 'POST', body: f }).then(() => { setF({ username: '', name: '', password: '', role: 'qc' }); load(); }).catch(err);
  return (<>
    {adm && <div className="card row"><b>Add user ({us.filter(u => u.role !== 'admin').length}/50)</b>
      {['username', 'name', 'password'].map(k => <input key={k} style={{ width: 160 }} type={k === 'password' ? 'password' : 'text'} placeholder={k} value={f[k]} onChange={e => setF({ ...f, [k]: e.target.value })} />)}
      <select style={{ width: 130 }} value={f.role} onChange={e => setF({ ...f, role: e.target.value })}><option value="qc">QC</option><option value="supervisor">Supervisor</option></select>
      <button className="pri" style={{ width: 90 }} onClick={add}>Add</button></div>}
    <div className="card scroll"><table><thead><tr><th>User</th><th>Role</th>{adm && <><th>Active</th><th>Reports</th></>}<th>Authorized datasets</th>{adm && <th></th>}</tr></thead><tbody>
      {us.map(u => <tr key={u.id}><td>{u.username}<br /><small>{u.name}</small></td><td>{u.role}</td>
        {adm && <><td><input type="checkbox" checked={u.active} disabled={u.role === 'admin'} onChange={e => upd(u.id, { active: e.target.checked })} /></td>
          <td><input type="checkbox" checked={u.can_report} disabled={u.role === 'admin'} onChange={e => upd(u.id, { can_report: e.target.checked })} /></td></>}
        <td>{u.role === 'admin' ? 'All' : <details><summary>{u.datasets.length} selected</summary>
          <button onClick={() => upd(u.id, { datasets: ds })}>Select all</button> <button onClick={() => upd(u.id, { datasets: [] })}>None</button>
          {ds.map(d => <label key={d} style={{ fontWeight: 400 }}><input type="checkbox" style={{ width: 'auto' }} checked={u.datasets.includes(d)} onChange={e => upd(u.id, { datasets: e.target.checked ? [...u.datasets, d] : u.datasets.filter(x => x !== d) })} /> {d}</label>)}</details>}</td>
        {adm && <td>{u.role !== 'admin' && <><button onClick={() => { const p = prompt('New password (6+ chars)'); if (p) upd(u.id, { password: p }); }}>Reset password</button> <button onClick={() => confirm('Delete user?') && api('/users/' + u.id, { method: 'DELETE' }).then(load)}>🗑</button></>}</td>}</tr>)}
    </tbody></table></div></>);
}

export function Uploads({ settings }) {
  const [log, setLog] = useState([]), [msg, setMsg] = useState(''), [S, setS] = useState(settings);
  const load = () => api('/uploads').then(setLog); useEffect(load, []);
  const xl = async e => {
    const f = e.target.files[0]; if (!f) return;
    const wb = XLSX.read(await f.arrayBuffer(), { cellDates: true }), ws = wb.Sheets.Report || wb.Sheets[wb.SheetNames[0]];
    const keep = ['Project Name', 'Date', 'Employee Name', 'Login Id', 'No. of Assets', 'No. of Annotation'];
    const rows = XLSX.utils.sheet_to_json(ws, { raw: false, dateNF: 'yyyy-mm-dd', defval: '' }).map(r => Object.fromEntries(keep.map(k => [k, r[k]])));
    try { const d = await api('/upload/assignments', { method: 'POST', body: { filename: f.name, rows } }); setMsg(`Assignment list loaded: ${d.rows} rows (${d.skipped} skipped)`); load(); } catch (x) { setMsg(x.message); }
  };
  const csv = e => {
    const f = e.target.files[0]; if (!f) return;
    Papa.parse(f, { header: true, skipEmptyLines: true, complete: async r => { try { const d = await api('/upload/errors', { method: 'POST', body: { rows: r.data } }); setMsg(`Error list refreshed: ${d.tags} tags`); } catch (x) { setMsg(x.message); } } });
  };
  const sv = () => api('/settings', { method: 'PUT', body: S }).then(() => setMsg('Settings saved')).catch(e => setMsg(e.message));
  return (<>
    <div className="card"><b>Assignment Excel (.xlsx) — upload at least every {S.stale_hours}h</b><br /><input type="file" accept=".xlsx,.xls" onChange={xl} />
      <br /><br /><b>Error list (.csv)</b><br /><input type="file" accept=".csv" onChange={csv} /><p>{msg}</p></div>
    <div className="card"><b>Recent uploads</b><table><tbody>{log.map((l, i) => <tr key={i}><td>{l.filename}</td><td>{l.row_count} rows</td><td>{new Date(l.uploaded_at).toLocaleString()}</td></tr>)}</tbody></table></div>
    <div className="card row"><b>Settings</b>{[['audit_min', 'Audit window min (h)'], ['audit_max', 'Audit window max (h)'], ['stale_hours', 'List expiry (h)'], ['idle_logout', 'Auto logout (min)']].map(([k, l]) =>
      <label key={k}>{l}<input type="number" value={S[k]} onChange={e => setS({ ...S, [k]: e.target.value })} /></label>)}<button className="pri" style={{ width: 90 }} onClick={sv}>Save</button></div>
  </>);
}
