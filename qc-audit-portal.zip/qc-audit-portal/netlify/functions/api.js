import { neon } from '@neondatabase/serverless';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { SCHEMA } from './schema.js';

const sql = neon(process.env.DATABASE_URL || process.env.NETLIFY_DATABASE_URL);
const q = (t, p = []) => sql.query(t, p);
const SECRET = process.env.JWT_SECRET;
const IST = "(now() at time zone 'Asia/Kolkata')::date";
let ready; const init = () => (ready ||= (async () => { for (const s of SCHEMA) await q(s); })());
const J = (c, b) => ({ statusCode: c, headers: { 'content-type': 'application/json' }, body: JSON.stringify(b) });
const fail = (code, msg) => { throw Object.assign(new Error(msg), { code }); };
const pub = u => ({ id: u.id, username: u.username, name: u.name, role: u.role, can_report: u.can_report });
const canReport = u => u.role !== 'qc' || u.can_report;
const DEF = { audit_min: 24, audit_max: 48, stale_hours: 36, idle_logout: 30 };
const settings = async () => { const o = { ...DEF }; for (const r of await q('select k,v from settings')) o[r.k] = Number(r.v); return o; };
const auth = async e => { try { const { id } = jwt.verify((e.headers.authorization || '').slice(7), SECRET); const [u] = await q('select id,username,name,role,active,can_report from users where id=$1', [id]); return u?.active ? u : null; } catch { return null; } };

// QC score: image score = 0 if the image has any error, else 100. Polygon accuracy = (polygons - errors) / polygons.
const calc = (tags, P) => { const E = tags.includes('NO_ERROR') ? 0 : tags.length; return { E, acc: E ? Math.max(0, Math.round((P - E) / P * 10000) / 100) : 100, img: E ? 0 : 100 }; };
async function check(b) {
  const P = Number(b.polygons), n = (b.task_name || '').trim(), t = b.tags;
  if (!Number.isInteger(P) || P < 1) fail(400, 'Total polygons must be a whole number of 1 or more');
  if (!n || n.length > 100) fail(400, 'Task/clip name is required (max 100 characters)');
  if (!Array.isArray(t) || !t.length) fail(400, 'Select at least one error tag (or NO_ERROR)');
  const u = [...new Set(t)];
  if ((await q('select tag from error_tags where active and tag=any($1)', [u])).length !== u.length) fail(400, 'Unknown error tag');
  if (u.includes('NO_ERROR') && u.length > 1) fail(400, 'NO_ERROR cannot be combined with other tags');
  return { P, n, t: u };
}
const push = async r => {
  if (!process.env.SHEET_WEBHOOK_URL) return;
  try { await fetch(process.env.SHEET_WEBHOOK_URL, { method: 'POST', headers: { 'content-type': 'text/plain' }, body: JSON.stringify({ token: process.env.SHEET_TOKEN, row: [r.id, r.ts, r.qc_user, r.labeler_id, r.agent, r.dataset, r.task_name, r.error_tags.join(', '), r.error_count, r.total_polygons, Number(r.polygon_accuracy), r.image_score] }) }); } catch {}
};
const RET = "returning id,qc_user,labeler_id,agent,dataset,task_name,error_tags,error_count,total_polygons,polygon_accuracy,image_score,to_char(submitted_at at time zone 'Asia/Kolkata','YYYY-MM-DD HH24:MI:SS') ts";

const tries = {};
async function login({ b, e }) {
  const k = (b.username || '') + (e.headers['x-nf-client-connection-ip'] || ''), t = tries[k] || { n: 0, at: 0 };
  if (t.n >= 5 && Date.now() - t.at < 9e5) fail(429, 'Too many attempts. Try again in 15 minutes.');
  const [c] = await q('select count(*)::int n from users');
  if (!c.n && b.username && b.username === process.env.ADMIN_USER && b.password === process.env.ADMIN_PASSWORD)
    await q("insert into users(username,name,pass_hash,role,can_report) values($1,'Super Admin',$2,'admin',true)", [b.username, await bcrypt.hash(b.password, 10)]);
  const [u] = await q('select * from users where username=$1', [b.username || '']);
  if (!u || !(await bcrypt.compare(b.password || '', u.pass_hash))) { tries[k] = { n: t.n + 1, at: Date.now() }; fail(401, 'Invalid username or password'); }
  if (!u.active) fail(403, 'Account is inactive. Contact the administrator.');
  delete tries[k];
  return { token: jwt.sign({ id: u.id }, SECRET, { expiresIn: '12h' }) };
}
async function me({ u }) {
  const [t] = await q(`select coalesce(sum(seconds),0)::int s from time_log where user_id=$1 and day=${IST}`, [u.id]);
  const [up] = await q('select max(uploaded_at) at from uploads'); const S = await settings();
  return { user: pub(u), today_seconds: t.s, settings: S, last_upload: up.at, stale: !up.at || Date.now() - new Date(up.at) > S.stale_hours * 36e5 };
}
async function options({ u }) {
  const S = await settings(), [up] = await q('select max(id) m,max(uploaded_at) at from uploads'), admin = u.role === 'admin';
  const rows = await q(`select labeler_id,agent,dataset,work_date::text wd,round(extract(epoch from (now()-(work_date::timestamp at time zone 'Asia/Kolkata')))/3600)::int age_h from assignments where upload_id=$1 and ($2 or dataset in (select dataset from user_datasets where user_id=$3)) order by labeler_id`, [up.m, admin, u.id]);
  const errors = await q('select tag,category,definition,active from error_tags order by category,tag');
  const [c] = await q(`select count(*)::int n from records where qc_user=$1 and (submitted_at at time zone 'Asia/Kolkata')::date=${IST}`, [u.username]);
  return { rows, errors, settings: S, today_count: c.n, stale: !up.at || Date.now() - new Date(up.at) > S.stale_hours * 36e5 };
}
async function addRec({ u, b }) {
  const S = await settings(), [up] = await q('select max(id) m,max(uploaded_at) at from uploads');
  if (u.role !== 'admin' && (!up.at || Date.now() - new Date(up.at) > S.stale_hours * 36e5)) fail(423, 'Labeler list is outdated. Please contact the Administration.');
  const { P, n, t } = await check(b);
  const [a] = await q('select agent from assignments where upload_id=$1 and labeler_id=$2 and dataset=$3 limit 1', [up.m, b.labeler_id, b.dataset]);
  if (!a) fail(400, 'Labeler / dataset is not in the current list');
  if (u.role !== 'admin' && !(await q('select 1 from user_datasets where user_id=$1 and dataset=$2', [u.id, b.dataset])).length) fail(403, 'You are not authorized for this dataset');
  if (!b.force && (await q('select 1 from records where labeler_id=$1 and dataset=$2 and task_name=$3', [b.labeler_id, b.dataset, n])).length) fail(409, 'Duplicate entry');
  const c = calc(t, P);
  const [r] = await q(`insert into records(qc_user,labeler_id,agent,dataset,task_name,error_tags,error_count,total_polygons,polygon_accuracy,image_score,upload_id) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) ${RET}`, [u.username, b.labeler_id, a.agent, b.dataset, n, t, c.E, P, c.acc, c.img, up.m]);
  await push(r); return { ok: true, id: r.id, image_score: c.img, polygon_accuracy: c.acc };
}
async function updRec({ b, id }) {
  const { P, n, t } = await check(b), c = calc(t, P);
  await q('update records set task_name=$2,error_tags=$3,error_count=$4,total_polygons=$5,polygon_accuracy=$6,image_score=$7 where id=$1', [+id, n, t, c.E, P, c.acc, c.img]); return { ok: true };
}
async function recs({ qs }) {
  const p = [qs.from || '2000-01-01', qs.to || '2999-01-01']; let w = "(submitted_at at time zone 'Asia/Kolkata')::date between $1::date and $2::date";
  if (qs.q) { p.push('%' + qs.q + '%'); w += " and (labeler_id||' '||agent||' '||qc_user||' '||dataset||' '||task_name||' '||array_to_string(error_tags,' ')) ilike $3"; }
  return q(`select id,qc_user,labeler_id,agent,dataset,task_name,error_tags,error_count,total_polygons,polygon_accuracy::float,image_score,to_char(submitted_at at time zone 'Asia/Kolkata','YYYY-MM-DD HH24:MI:SS') ts from records where ${w} order by submitted_at desc limit 50000`, p);
}
const addTime = ({ u, b }) => q(`insert into time_log(user_id,day,seconds) values($1,${IST},$2) on conflict(user_id,day) do update set seconds=time_log.seconds+$2`, [u.id, Math.min(30, Math.max(0, Math.floor(+b.seconds || 0)))]).then(() => ({ ok: true }));
const timeRep = ({ qs }) => q('select t.day::text day,u.username,u.name,t.seconds from time_log t join users u on u.id=t.user_id where t.day between $1::date and $2::date order by t.day desc,u.username', [qs.from || '2000-01-01', qs.to || '2999-01-01']);

const ulist = () => q(`select u.id,u.username,u.name,u.role,u.active,u.can_report,coalesce(array_agg(d.dataset) filter (where d.dataset is not null),'{}') datasets from users u left join user_datasets d on d.user_id=u.id group by u.id order by u.role,u.username`);
async function addUser({ b }) {
  if (!b.username || !b.password || b.password.length < 6) fail(400, 'Username and a password of 6+ characters are required');
  if ((await q("select count(*)::int n from users where role<>'admin'"))[0].n >= 50) fail(400, 'User limit (50) reached');
  try { await q('insert into users(username,name,pass_hash,role) values($1,$2,$3,$4)', [b.username.trim(), b.name || '', await bcrypt.hash(b.password, 10), b.role === 'supervisor' ? 'supervisor' : 'qc']); } catch { fail(409, 'Username already exists'); }
  return { ok: true };
}
async function updUser({ u, b, id }) {
  id = +id; const [t] = await q('select role from users where id=$1', [id]); if (!t) fail(404, 'No such user');
  if (b.datasets) { await q('delete from user_datasets where user_id=$1', [id]); if (b.datasets.length) await q('insert into user_datasets select $1,unnest($2::text[])', [id, b.datasets]); }
  if (u.role === 'admin') {
    if (t.role === 'admin' && b.active === false) fail(400, 'Cannot deactivate the super admin');
    if (b.active !== undefined) await q('update users set active=$2 where id=$1', [id, !!b.active]);
    if (b.can_report !== undefined) await q('update users set can_report=$2 where id=$1', [id, !!b.can_report]);
    if (b.password) { if (b.password.length < 6) fail(400, 'Password too short'); await q('update users set pass_hash=$2 where id=$1', [id, await bcrypt.hash(b.password, 10)]); }
  }
  return { ok: true };
}
async function upAssign({ b }) {
  const m = new Map();
  for (const r of b.rows || []) if (r['Login Id'] && r['Project Name'] && r['Employee Name'] && r['Employee Name'] !== 'No record found' && /^\d{4}-\d{2}-\d{2}$/.test(r.Date)) m.set([r['Login Id'], r['Project Name'], r.Date].join('|'), r);
  const v = [...m.values()]; if (!v.length) fail(400, 'No valid rows (need Project Name, Date, Employee Name, Login Id)');
  const [up] = await q('insert into uploads(filename,row_count) values($1,$2) returning id', [b.filename || '', v.length]);
  const c = k => v.map(r => String(r[k]).trim()), n = k => v.map(r => parseInt(r[k]) || 0);
  await q('insert into assignments(upload_id,labeler_id,agent,dataset,work_date,assets,annotations) select $1,* from unnest($2::text[],$3::text[],$4::text[],$5::date[],$6::int[],$7::int[])', [up.id, c('Login Id'), c('Employee Name'), c('Project Name'), c('Date'), n('No. of Assets'), n('No. of Annotation')]);
  return { ok: true, rows: v.length, skipped: (b.rows || []).length - v.length };
}
async function upErrors({ b }) {
  const v = (b.rows || []).filter(r => r.standard_tag); if (!v.length) fail(400, 'No rows with standard_tag');
  const t = v.map(r => r.standard_tag.trim());
  await q('insert into error_tags(tag,category,definition,active) select a,b,c,true from unnest($1::text[],$2::text[],$3::text[]) x(a,b,c) on conflict(tag) do update set category=excluded.category,definition=excluded.definition,active=true', [t, v.map(r => r.category || ''), v.map(r => r.standard_definition || '')]);
  await q('update error_tags set active=false where tag<>all($1)', [t]); return { ok: true, tags: t.length };
}
async function putSettings({ b }) { for (const k of Object.keys(DEF)) if (b[k] !== undefined) await q('insert into settings(k,v) values($1,$2) on conflict(k) do update set v=excluded.v', [k, String(+b[k])]); return { ok: true }; }

const R = [], add = (m, p, a, f) => R.push([m, new RegExp(`^${p}$`), a, f]), AD = ['admin'], SV = ['admin', 'supervisor'];
add('POST', '/login', null, login); add('GET', '/me', 'any', me); add('GET', '/options', 'any', options);
add('POST', '/records', 'any', addRec); add('GET', '/records', 'report', recs);
add('PUT', '/records/(\\d+)', AD, updRec); add('DELETE', '/records/(\\d+)', AD, ({ id }) => q('delete from records where id=$1', [+id]).then(() => ({ ok: true })));
add('POST', '/time', 'any', addTime); add('GET', '/time-report', 'report', timeRep);
add('GET', '/users', SV, ulist); add('POST', '/users', AD, addUser); add('PUT', '/users/(\\d+)', SV, updUser);
add('DELETE', '/users/(\\d+)', AD, async ({ id }) => { await q("delete from users where id=$1 and role<>'admin'", [+id]); return { ok: true }; });
add('GET', '/datasets', SV, async () => (await q('select distinct dataset from assignments where upload_id=(select max(id) from uploads) order by 1')).map(r => r.dataset));
add('POST', '/upload/assignments', AD, upAssign); add('POST', '/upload/errors', AD, upErrors);
add('GET', '/uploads', AD, () => q('select filename,row_count,uploaded_at from uploads order by id desc limit 5'));
add('PUT', '/settings', AD, putSettings);

export const handler = async e => {
  try {
    await init();
    const path = e.path.replace(/^(\/\.netlify\/functions\/api|\/api)/, '') || '/';
    for (const [m, re, a, f] of R) {
      const x = re.exec(path); if (m !== e.httpMethod || !x) continue;
      let u = null;
      if (a) {
        u = await auth(e); if (!u) return J(401, { error: 'Login required' });
        if (a === 'report' ? !canReport(u) : Array.isArray(a) && !a.includes(u.role)) return J(403, { error: 'Not allowed' });
      }
      return J(200, await f({ u, b: e.body ? JSON.parse(e.body) : {}, id: x[1], qs: e.queryStringParameters || {}, e }));
    }
    return J(404, { error: 'Not found' });
  } catch (err) { return J(err.code || 500, { error: err.code ? err.message : 'Server error' }); }
};
