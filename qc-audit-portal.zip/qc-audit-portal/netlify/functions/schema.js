export const SCHEMA = [
`create table if not exists users(id serial primary key, username text unique not null, name text, pass_hash text not null, role text not null default 'qc' check(role in ('admin','supervisor','qc')), active boolean default true, can_report boolean default false)`,
`create table if not exists user_datasets(user_id int references users(id) on delete cascade, dataset text, primary key(user_id,dataset))`,
`create table if not exists uploads(id serial primary key, filename text, row_count int, uploaded_at timestamptz default now())`,
`create table if not exists assignments(id serial primary key, upload_id int, labeler_id text, agent text, dataset text, work_date date, assets int, annotations int)`,
`create index if not exists ix_assign on assignments(upload_id,labeler_id)`,
`create table if not exists error_tags(tag text primary key, category text, definition text, active boolean default true)`,
`create table if not exists records(id serial primary key, qc_user text, labeler_id text, agent text, dataset text, task_name text check(char_length(task_name)<=100), error_tags text[], error_count int, total_polygons int, polygon_accuracy numeric, image_score int, submitted_at timestamptz default now(), upload_id int)`,
`create table if not exists time_log(user_id int references users(id) on delete cascade, day date, seconds int default 0, primary key(user_id,day))`,
`create table if not exists settings(k text primary key, v text)`
];
